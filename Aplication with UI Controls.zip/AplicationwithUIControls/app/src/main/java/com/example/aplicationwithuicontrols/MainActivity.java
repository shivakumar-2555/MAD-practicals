package com.example.aplicationwithuicontrols;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.aplicationwithuicontrols.R;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views by their IDs
        EditText nameEditText = findViewById(R.id.nameEditText);
        CheckBox greetingCheckBox = findViewById(R.id.greetingCheckBox);
        Button greetButton = findViewById(R.id.greetButton);
        TextView outputText = findViewById(R.id.outputText);

        // Set an OnClickListener for the greet button
        greetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the name input and trim any extra spaces
                String name = nameEditText.getText().toString().trim();

                // Check the conditions for showing appropriate messages
                if (!name.isEmpty() && greetingCheckBox.isChecked()) {
                    outputText.setText("Hello, " + name + "!");
                } else if (!greetingCheckBox.isChecked()) {
                    outputText.setText("Please check the box to receive a greeting.");
                } else {
                    outputText.setText("Please enter your name.");
                }
            }
        });
    }
}
