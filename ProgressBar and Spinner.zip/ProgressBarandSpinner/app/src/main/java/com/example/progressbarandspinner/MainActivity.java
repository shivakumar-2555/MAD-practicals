package com.example.progressbarandspinner;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Spinner spinner;
    ProgressBar progressBar;
    Button startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        spinner = findViewById(R.id.spinner);
        progressBar = findViewById(R.id.progressBar);
        startButton = findViewById(R.id.startButton);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.spinner_items, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressBar
                progressBar.setVisibility(View.VISIBLE);

                // Simulate a background task using a Handler
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Hide ProgressBar and show a Toast message
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(MainActivity.this, "Task Completed!", Toast.LENGTH_SHORT).show();
                    }
                }, 5000); // Delay for 5 seconds
            }
        });
    }
}